const books = [
    {
      "id": 1,
      "title": "Don Quijote de la Mancha",
      "author": "Miguel de Cervantes",
      "year": 1605
    },
    {
      "id": 2,
      "title": "Moby Dick",
      "author": "Herman Melville",
      "year": 1851
    },
    {
      "id": 3,
      "title": "Orgullo y Prejuicio",
      "author": "Jane Austen",
      "year": 1813
    },
    {
      "id": 4,
      "title": "Crimen y Castigo",
      "author": "Fyodor Dostoevsky",
      "year": 1866
    },
    {
      "id": 5,
      "title": "La Odisea",
      "author": "Homero",
      "year": -800
    }
  ]

module.exports = books;